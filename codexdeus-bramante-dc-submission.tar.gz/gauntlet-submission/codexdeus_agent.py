"""DavidBramanteAI tournament agent."""



from __future__ import annotations

import argparse
import asyncio
import base64
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
from urllib.parse import urlparse
import uuid

from dotenv import load_dotenv
from openai import AsyncOpenAI, BadRequestError

from arena_clients import HttpArenaClient, McpArenaClient
from arena_clients.config import ensure_connected, get_api_base, get_arena_api_key, get_mcp_url, get_proxy_host, agent_id_problem
from arena_clients.proxy_headers import build_proxy_headers
from arena_clients.session_monitor import monitor_session
from base_strategy import ChallengeContext
from model_selector import require_explicit_model
from my_strategy import MyStrategy
from exact_tools import DEFINITIONS as EXACT_TOOLS, execute as execute_exact
import smt_tools
from session_flow import wait_for_challenge,wait_for_running,managed_mcp_type,exception_diagnostic
from tool_loop import SolveResult, solve_text
from fast_ordering import try_fast_ordering
from submission_recovery import checkpoint_path,submit_text_exact,SubmissionGate,UnsettledSubmission,compact_receipt_summary
from model_failover import ModelFailover
from retrieval_fastpath import try_retrieval
from config_fastpath import try_config
from image_tools import ImageTools,image_data,render_prompt,preserve_input_artifact,failed
from runtime_metadata import fetch_model_rows,load_clues,completed_text_tools,bind_tool_identity,normalize_mcp_reply,rank_planners


McpArenaClient=managed_mcp_type(McpArenaClient)


def save_record(directory: Path, record: dict):
    directory.mkdir(parents=True,exist_ok=True)
    directory.chmod(0o700)
    file=directory/"run.json"
    with file.open("x",encoding="utf-8") as handle:
        json.dump(record,handle,indent=2,allow_nan=False,default=str)
        handle.write("\n")
    file.chmod(0o600)
    return file


def append_model_event(directory: Path,event: dict):

    directory.mkdir(parents=True,exist_ok=True);directory.chmod(0o700)
    path=directory/'model-events.jsonl'
    with path.open('a',encoding='utf-8') as handle:
        path.chmod(0o600)
        handle.write(json.dumps(event,allow_nan=False)+'\n');handle.flush()


async def run(output: Path, model_override: str | None, *, allow_model: bool = True, enable_failover: bool = True,
              image_model_override: str | None = None,image_profile: str = 'constraints'):
    strategy=MyStrategy()
    agent_id=os.getenv("AGENT_ID","").strip()
    if not agent_id or agent_id_problem(agent_id):
        raise SystemExit("Set a unique AGENT_ID before starting")
    key=get_arena_api_key()
    if sys.platform != 'linux':
        raise SystemExit('Run the agent inside the isolated Linux runtime, not on the Mac host')
    local_coordinator=urlparse(get_api_base()).hostname in {"localhost","127.0.0.1","::1"}
    model_key=(os.getenv("REHEARSAL_MODEL_API_KEY") or key) if local_coordinator else key
    await asyncio.to_thread(ensure_connected)
    http=HttpArenaClient(timeout=10)
    origin = get_api_base()
    gate = SubmissionGate(checkpoint_path(output, agent_id, local_coordinator=local_coordinator, origin=origin),
                          agent_id, origin)
    try:
        previous=await gate.reconcile(http)
    except Exception as exc:
        save_record(output,{'agent_id':agent_id,'official_score':None,'error':exception_diagnostic(exc),
                           'registration_skipped':True,'reason':'Prior final submission is unresolved'})
        raise
    if previous:
        save_record(output, {'agent_id': agent_id, 'registration_skipped': True,
                             'previous_submission_reconciled': True, 'official_score': None})
        return
    agent_name=strategy.agent_name
    registration=await asyncio.to_thread(http.register,agent_id,agent_name)
    monitor=monitor_session(http,agent_id).start()
    record={"agent_id":agent_id,"agent_name":agent_name,"session_id":registration.session_id,"variant":"DavidBramanteAI",
            "started_at_utc":datetime.now(timezone.utc).isoformat(),"official_score":None,
            "result":{},"challenge":{},"error":None}
    record["code_sha256"]={name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
                           for name in ["codexdeus_agent.py","tool_loop.py","exact_tools.py","smt_tools.py","fast_ordering.py","submission_recovery.py","model_failover.py","retrieval_fastpath.py","config_fastpath.py","image_tools.py","runtime_metadata.py","session_flow.py","my_strategy.py"]}
    record["token_accounting"]="Completed model responses only; failed/canceled requests may have additional proxy-billed usage"
    record['runtime_options']={'initial_text_model_override':model_override,'image_model_override':image_model_override,'image_prompt_profile':image_profile}
    record['registration_started_at']=getattr(registration,'started_at',None)
    started=time.monotonic()
    record['stages']=[]
    def stage(name):
        record['stages'].append({'stage':name,'since_record_start_s':time.monotonic()-started})
    try:
        record['round_gate'] = await asyncio.to_thread(wait_for_running, http, agent_id,
                                                       allow_missing_phase=local_coordinator)
        stage('round_ready')
        stage('mcp_connecting')
        record['transport_policy']='owned-setup-v1'
        mcp_client=McpArenaClient()
        connection_events=getattr(mcp_client,'connection_events',[])
        record['mcp_events']=connection_events if isinstance(connection_events,list) else []
        async with mcp_client as mcp:
            stage('mcp_connected')
            definitions=await mcp.list_tool_defs()
            record['initial_tool_definitions']=[d.model_dump() for d in definitions]
            stage('catalog_loaded')
            names=[d.name for d in definitions]
            modality=await asyncio.to_thread(McpArenaClient.detect_modality,names,agent_id)
            stage('modality_detected')

            data,received=await wait_for_challenge(mcp,agent_id,modality)
            stage('challenge_received')
            raw_budget=data.get('time_remaining_s')
            supplied=float(data.get('max_time_s',0) if raw_budget is None else raw_budget)
            if not math.isfinite(supplied) or supplied <= 0:raise RuntimeError("Challenge did not provide a usable time budget")
            deadline=received+supplied
            reserve=min(10,max(4,supplied*.08))
            if modality!="image":
                record['clue_loading']=await load_clues(mcp,agent_id,data,timeout_s=min(5,max(.01,supplied*.1)))
            preflight_tools=completed_text_tools(record.get('clue_loading',{})) if modality!='image' else ['arena.image.get_challenge']
            record['preflight_tools']=preflight_tools
            stage('clues_loaded')
            http.timeout=min(3,max(.05,deadline-time.monotonic()-reserve))
            if modality=='image':
                await asyncio.wait_for(mcp.broadcast_image_thought('Reading task constraints and discovering relevant tools.',agent_id),timeout=http.timeout)
            else:
                await asyncio.to_thread(http.broadcast_thought,agent_id,"Reading task constraints and discovering relevant tools.")
            stage('thought_delivered')
            try:
                fresh=await asyncio.wait_for(mcp.list_tool_defs(),timeout=min(3,max(.1,deadline-time.monotonic())))
                definitions=fresh
                names=[d.name for d in definitions]
            except (Exception,asyncio.TimeoutError):
                pass
            stage('catalog_refreshed')
            record['active_tool_definitions']=[d.model_dump() for d in definitions]
            images={};model=None
            record['challenge']={k:v for k,v in data.items() if k not in {'input_image_uri','raw_data'}}
            fast={'used':False,'reason':'image_task'}
            if modality!='image':
                stage('fast_path_started')
                try:
                    ordering_data={**data,'required_tools':[name for name in data.get('required_tools',[]) if name not in preflight_tools]}
                    fast=await asyncio.wait_for(try_fast_ordering(ordering_data),timeout=min(3,max(.01,deadline-time.monotonic()-4)))
                except asyncio.TimeoutError:
                    fast={'used':False,'reason':'fast_path_timeout'}
                if not fast['used']:
                    configured=try_config(data)
                    if configured['used']:fast=configured
                if not fast['used']:
                    try:
                        retrieval=await asyncio.wait_for(try_retrieval({**data,'agent_id':agent_id},
                            [d.model_dump() for d in definitions],mcp.call_tool),timeout=min(9,max(.01,deadline-time.monotonic()-4)))
                    except asyncio.TimeoutError:retrieval={'used':False,'reason':'retrieval_timeout'}
                    record['retrieval_attempt']=retrieval
                    if retrieval['used']:fast=retrieval
                    elif retrieval.get('evidence'):
                        data['prefetched_evidence']=retrieval['evidence']
                stage('fast_path_finished')
            record['fast_path']=fast
            record['smt_available']=smt_tools.available()
            if fast['used']:
                solve=SolveResult(answer=fast['answer'],raw_answer='ANSWER: '+fast['answer'],
                                  tools_used=fast.get('tools_used',['local_smt_order']),tool_attempts=fast.get('tool_attempts',1),model_calls=0,
                                  elapsed_s=fast['elapsed_s'],reason=fast.get('route','deterministic_ordering'),
                                  events=[{'event':fast.get('route','deterministic_ordering'),'grammar':fast.get('grammar')}])
                record['model']=None
                record['model_calls_disabled']=not allow_model
            else:
                if not allow_model:
                    raise RuntimeError('Offline run declined: no fully supported deterministic solution')
                scope=await asyncio.wait_for(asyncio.to_thread(http.fetch_usage_scope),timeout=min(3,max(.05,deadline-time.monotonic()-reserve)))
                if urlparse(get_api_base()).hostname in {"localhost","127.0.0.1","::1"} and urlparse(get_proxy_host()).hostname not in {"localhost","127.0.0.1","::1"}:

                    record["local_usage_scope"]=scope
                    scope=None
                    os.environ.pop("ARENA_USAGE_SCOPE",None)
                if scope:os.environ["ARENA_USAGE_SCOPE"]=scope
                model_rows=await fetch_model_rows(get_proxy_host(),model_key,timeout_s=min(8,max(.05,deadline-time.monotonic()-reserve-2)))
                record['advertised_models']=model_rows
                roster=[row['id'] for row in model_rows]
                image_models=strategy.prefer_image_models(roster,model_rows=model_rows)
                if modality=='image' and image_model_override:
                    if image_model_override not in image_models:raise ValueError('Image model override is not advertised as image-capable')
                    image_models=[image_model_override]
                stage('model_metadata_ready')

                planner_roster=[m for m in roster if m not in image_models]
                if not planner_roster:planner_roster=list(roster)
                ctx=ChallengeContext(challenge_type="text",description=str(data.get("description", "")),available_models=planner_roster,
                                     max_time_s=int(data.get("max_time_s") or supplied))
                ranked=rank_planners(strategy.rank_models(ctx,planner_roster),modality=modality)
                model=require_explicit_model(model_override or strategy.pick_model("solve",ranked,ctx),planner_roster,source="DavidBramanteAI")
                record["model"]=model
                record['initial_model']=model
                images={}
                input_uri=str(data.get("input_image_uri") or "")
                if modality=="image" and input_uri:record["image_input"]=preserve_input_artifact(output,input_uri)
                public_data={k:v for k,v in data.items() if k not in {"input_image_uri","raw_data"}}
                public_data['agent_id']=agent_id
                public_data['harness_completed_tools']=preflight_tools
                if modality=="image":
                    public_data['harness_will_submit_via']='arena.image.submit_edit'
                    public_data["input_image_uri"]="INPUT_IMAGE"
                    image_ctx=ChallengeContext(challenge_type="image",available_models=roster,image_url=input_uri)
                    public_data["available_image_models"]=image_models
                    public_data["submission_instruction"]="Use the image tools to produce the requested result. Return ANSWER: RESULT_IMAGE_N, selecting the generated image token. INPUT_IMAGE resolves to the original image when passed to a tool."
                record["challenge"]={k:v for k,v in public_data.items()}
                local_definitions=[t for t in EXACT_TOOLS if t['name'] not in names]
                local_names={t['name'] for t in local_definitions}
                if smt_tools.available() and smt_tools.DEFINITION['name'] not in names:
                    local_definitions.append(smt_tools.DEFINITION)
                    local_names.add(smt_tools.DEFINITION['name'])
                record['smt_available']=smt_tools.available()

                remote_definitions=[d.model_dump() for d in definitions]
                async def remote_call(name,arguments):
                    scoped=bind_tool_identity(name,arguments,remote_definitions,agent_id)
                    return normalize_mcp_reply(await mcp.call_tool(name,scoped))

                image_runtime=ImageTools(remote_definitions,image_models,remote_call,
                    deadline=deadline-reserve-12)
                images=image_runtime.outputs


                challenge_rules=(str(data.get('prompt') or '')+'\n'+str(data.get('edit_prompt') or '')+'\n'+str(data.get('reference_notes') or '')+'\n'+str(data.get('description') or '')).strip()

                def build_constraint_check(rules_text):

                    rules_lower=rules_text.lower()
                    checks=[]
                    if any(s in rules_lower for s in ('no text','without text','no words','no lettering','text-free')):
                        checks.append('text, letters, or words')
                    if any(s in rules_lower for s in ('no logo','without logo','logo-free')):
                        checks.append('logos or brand marks')
                    if any(s in rules_lower for s in ('no watermark','without watermark')):
                        checks.append('watermarks')
                    if any(s in rules_lower for s in ('no sign','without sign','no signage')):
                        checks.append('signs or signage')
                    if any(s in rules_lower for s in ('single person','one person','only one')):
                        checks.append('more than one person')
                    if any(s in rules_lower for s in ('no people','without people','no humans','no person')):
                        checks.append('people or humans')
                    if not checks:
                        return None
                    items=', '.join(checks)
                    return f"Look carefully at this image. Does it contain ANY of the following that should NOT be present: {items}? Answer YES if any violation is found, NO if the image is clean."

                constraint_question=build_constraint_check(challenge_rules)

                async def invoke(name,arguments):
                    if name=='local_smt_order' and name in local_names:
                        return await smt_tools.execute(arguments)
                    if name in local_names:
                        return execute_exact(name,arguments)
                    def resolve(value):
                        if isinstance(value,str):return input_uri if value=="INPUT_IMAGE" else images.get(value,value)
                        if isinstance(value,dict):return {k:resolve(v) for k,v in value.items()}
                        if isinstance(value,list):return [resolve(v) for v in value]
                        return value
                    if name in {'image_edit','image_generate'}:
                        image_arguments=resolve(arguments)
                        image_arguments['prompt']=render_prompt(data,image_arguments.get('prompt'),name,profile=image_profile)
                        if image_model_override:image_arguments['model']=image_model_override
                        record.setdefault('image_prompt_events',[]).append({'tool':name,'profile':image_profile,
                            'model_override':image_model_override,'prompt':image_arguments['prompt']})


                        result=await image_runtime.call(name,image_arguments)


                        if name=='image_generate' and constraint_question and not failed(result) and image_runtime.requests<3:
                            uri=result.get('image_uri') or result.get('image') or result.get('url')
                            if uri and isinstance(uri,str) and uri.startswith('RESULT_IMAGE'):
                                actual_uri=images.get(uri,uri)
                                if actual_uri and deadline-time.monotonic()>40:
                                    try:


                                        analysis=await asyncio.wait_for(
                                            remote_call('image_analyze',{'image_uri':actual_uri,'question':constraint_question,'model':'gemini-3.6-flash'}),
                                            timeout=15)
                                        analysis_text=str(analysis.get('content') or analysis.get('text') or analysis.get('answer') or analysis).lower()
                                        violation_found='yes' in analysis_text and 'no' not in analysis_text[:20]
                                        record.setdefault('constraint_checks',[]).append({
                                            'attempt':1,'uri':uri[:50],'question':constraint_question[:100],
                                            'analysis':analysis_text[:200],'violation_found':violation_found})
                                        if violation_found:

                                            record.setdefault('image_prompt_events',[]).append({'tool':name,'profile':image_profile,
                                                'retry_reason':'constraint_violation','prompt':image_arguments['prompt']})
                                            retry_result=await image_runtime.call(name,image_arguments)
                                            if not failed(retry_result):
                                                result=retry_result
                                    except Exception as exc:
                                        record.setdefault('constraint_checks',[]).append({
                                            'attempt':1,'error':type(exc).__name__})
                        return result
                    return await remote_call(name,resolve(arguments))

                params=strategy.get_llm_params(ctx)
                record['proxy_http_requests']=0
                async with AsyncOpenAI(base_url=get_proxy_host(),api_key=model_key,default_headers=build_proxy_headers(agent_id,scope),max_retries=0) as llm:
                    async def send(alias,messages,tools,timeout):
                        args={"model":alias,"messages":messages,"max_tokens":int(params.get("max_tokens",8192)),"timeout":timeout,
                              'temperature':float(params.get('temperature',0))}
                        if tools:args.update(tools=tools,tool_choice="auto")
                        try:
                            record['proxy_http_requests']+=1
                            response=await llm.chat.completions.create(**args)
                        except BadRequestError as exc:

                            if 'temperature' not in str(exc).lower():raise
                            args.pop('temperature')
                            record.setdefault('provider_parameter_adjustments',[]).append('temperature omitted after rejection')
                            record['proxy_http_requests']+=1
                            response=await llm.chat.completions.create(**args)
                        return response.model_dump()
                    offered=[d.model_dump() for d in definitions]
                    offered += local_definitions
                    router=ModelFailover([model]+ranked if enable_failover else [model],planner_roster,send,
                        max_switches=3 if enable_failover else 0,on_event=lambda event:append_model_event(output,event))
                    record['model_event_journal']='model-events.jsonl (diagnostic log; not a crash-resumable checkpoint)'
                    try:
                        solve=await solve_text(public_data,offered,router.complete,invoke,
                            budget_s=max(.01,deadline-time.monotonic()),reserve_s=min(10,max(4,supplied*.08)),
                            model_feedback=router.feedback,model_useful=router.useful,
                            answer_validator=image_runtime.problem if modality=='image' else None,
                            initial_tools_used=preflight_tools+(record.get('retrieval_attempt') or {}).get('tools_used',[]),
                            deferred_control_tools=['arena.image.submit_edit'] if modality=='image' else [],
                            initial_tool_attempts=(record.get('retrieval_attempt') or {}).get('tool_attempts',0))
                    finally:
                        record['model_recovery']=router.snapshot()
                        if modality=='image':record['image_recovery']=image_runtime.snapshot()
                    solve.model_calls=record['proxy_http_requests']
                    solve.prompt_tokens=router.prompt_tokens;solve.completion_tokens=router.completion_tokens
                    model=router.current;record['model']=model
            record["solver"]=asdict(solve)
            stage('solver_finished')
            answer=solve.answer
            if modality=='image' and not answer and len(images)==1:
                recovery=record.get('model_recovery',{})
                terminal_access=any(e.get('event') in {'model_policy_refusal','model_access_failure'} for e in recovery.get('events',[]))
                missing=set(data.get('required_tools',[]))-set(solve.tools_used)-{'arena.image.submit_edit'}
                if not terminal_access and not missing and solve.reason in {'model_error_or_timeout','turn_budget_exhausted','no_valid_answer'}:
                    answer=next(iter(images))
                    record['image_selection_fallback']={'reason':'single_successful_output_after_planner_failure',
                        'token':answer,'semantic_quality_validated':False}
            remaining=deadline-time.monotonic()
            if remaining<=0:raise TimeoutError('Challenge deadline expired before submission')
            http.timeout=min(remaining,8)
            if modality=="image":
                uri=images.get(answer)
                if not uri:
                    raise RuntimeError("No generated image available; no edited-image success can be claimed")
                content,suffix=image_data(uri)
                if content is not None:
                    output.mkdir(parents=True,exist_ok=True);output.chmod(0o700)
                    file=output/('submitted-image.'+suffix);file.write_bytes(content);file.chmod(0o600)
                    record['image_output']={'file':file.name,'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)}
                else:
                    record['image_output']={'uri':uri,'downloaded':False,'reason':'No external image URL is fetched by this runtime'}
                dispatched=time.monotonic();stage('submission_dispatched')
                record['submission_checkpoint']=gate.begin(started_at=record['registration_started_at'],
                    puzzle_id=data.get('puzzle_id') or data.get('challenge_id'),modality='image',answer=uri,record_directory=output)

                instruction=(data.get('edit_prompt') or data.get('prompt') or data.get('description') or 'task')[:300]
                is_edit=bool(data.get('input_image_uri'))
                if is_edit:
                    rationale=f"Edit applied: {instruction} The rest of the image was kept as it was."[:500]
                else:
                    blob=f"{instruction} {data.get('reference_notes') or ''}".lower()
                    no_text=any(s in blob for s in ('no text','without text','no words','no logo','watermark'))
                    rationale=(f"Generated: {instruction}"+(' No text, logos or watermarks.' if no_text else ''))[:500]
                try:
                    receipt=await asyncio.wait_for(mcp.submit_image(agent_id,uri,client_metrics={"model_name":model,"total_tokens":solve.prompt_tokens+solve.completion_tokens},rationale=rationale),timeout=max(30,remaining))
                except Exception as exc:
                    record['submission_error']=exception_diagnostic(exc)
                    receipt=await gate.reconcile(http)
            else:
                if not answer:raise RuntimeError("No valid final answer available")

                dispatched=time.monotonic();stage('submission_dispatched')
                record['submission_attempts']=[]
                record['submission_checkpoint']=gate.begin(started_at=record['registration_started_at'],
                    puzzle_id=data.get('puzzle_id') or data.get('challenge_id'),modality='text',answer=answer,record_directory=output)
                try:
                    receipt=await submit_text_exact(http,{
                        "agent_id":agent_id,"answer":answer,"client_metrics":{"model_name":model or 'deterministic-smt',
                        "prompt_tokens":solve.prompt_tokens,"completion_tokens":solve.completion_tokens,
                        "total_tokens":solve.prompt_tokens+solve.completion_tokens}},
                        deadline=deadline,on_event=record['submission_attempts'].append,max_attempts=2)
                except Exception as exc:
                    record['submission_error']=exception_diagnostic(exc)
                    receipt=await gate.reconcile(http)
            stage('submission_receipt')
            record['local_submission_dispatch_ms']=round((dispatched-received)*1000,3)
            record['submission_receipt_wait_ms']=round((time.monotonic()-dispatched)*1000,3)
            record['timing_note']='Local challenge receipt to client dispatch; not authoritative organizer GO-to-submit timing. Receipt wait is separate.'
            raw_score=receipt.get('score')
            score={k:v for k,v in raw_score.items() if k!='output_image_uri'} if isinstance(raw_score,dict) else raw_score
            record['result']={k:v for k,v in receipt.items() if k!='session_snapshot'}
            if isinstance(record['result'].get('answer'),str) and record['result']['answer'].startswith('data:image/'):
                record['result']['answer']='[image payload preserved in raw receipt]'
            if 'score' in receipt:record['result']['score']=score
            record['result']=compact_receipt_summary(record['result'])
            record['raw_submission_receipt']='submission-receipt.json'
            record['official_score']=score
            gate.settled(receipt)
            record["heat_elapsed_ms"]=round((time.monotonic()-received)*1000)
            print(json.dumps({"accepted":receipt.get("accepted"),"status":receipt.get("status"),"score":score,"local_evaluation":receipt.get("evaluation")},indent=2))
    except asyncio.CancelledError:
        record['error']={'type':'CancelledError'}
        raise
    except Exception as exc:

        record["error"]=exception_diagnostic(exc)
        raise
    finally:
        await monitor.stop()
        record["elapsed_ms"]=round((time.monotonic()-started)*1000)
        file=save_record(output,record)
        print(f"Run record: {file}")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path)
    parser.add_argument("--model",help="Optional initial model; must be present in the discovered roster")
    parser.add_argument('--image-model',help='Controlled comparison: use only this advertised image backend')
    parser.add_argument('--image-profile',choices=['baseline','constraints'],default='constraints')
    parser.add_argument('--single-model',action='store_true',help='Disable model switching for controlled comparisons')
    parser.add_argument('--no-model',action='store_true',help='Offline check: decline unsupported tasks without fetching a model roster or calling a model')
    args=parser.parse_args()
    load_dotenv(Path(__file__).resolve().parent/".env",override=False)
    output=args.output or Path("/tmp")/(datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")+"-"+uuid.uuid4().hex[:8])
    try:
        asyncio.run(run(output,args.model,allow_model=not args.no_model,enable_failover=not args.single_model,
                        image_model_override=args.image_model,image_profile=args.image_profile))
    except Exception as exc:
        print(f"Agent failed: {type(exc).__name__}; see the private run record.",file=sys.stderr)
        raise SystemExit(1) from None


if __name__=="__main__":main()
