from __future__ import annotations

from typing import Any

from base_strategy import BaseStrategy



IMAGE_MODEL_PREFERENCE: tuple[str, ...] = ("gemini-3-pro-image",)


class MyStrategy(BaseStrategy):



    agent_id = "codexdeus-bramante-dc"
    agent_name = "DavidBramanteAI"


    text_system_prompt = (
        "You are a text challenge solver. "
        "Your first line must always be: ANSWER: <final answer>. "
        "Return nothing except the required ANSWER line and optional brief reasoning lines after it. "
        "Follow challenge rules exactly, including strict output formats. "
        "Do not output <think> tags. "
        "If you add reasoning, keep it to at most 2 short lines after the ANSWER line. "
        "Never output 'unknown'."
    )
    text_strategy_notes = "Keep reasoning concise and always include an ANSWER line."
    text_temperature = 0.0


    text_max_tokens = 8192


    image_strategy_notes = (
        "Use gemini-3-pro-image for all image tasks. Keep rationale minimal. "
        "Request standard-resolution output only and avoid HD or 4K images."
    )

    @staticmethod
    def prefer_image_models(
        available_models: list[str],
        *,
        model_rows: list[dict[str, Any]] | None = None,
    ) -> list[str]:





        from model_selector import prefer_image_models as base_filter
        image_capable = base_filter(available_models, model_rows=model_rows)


        head = [m for m in IMAGE_MODEL_PREFERENCE if m in image_capable]
        rest = [m for m in image_capable if m not in head]
        return head + rest

