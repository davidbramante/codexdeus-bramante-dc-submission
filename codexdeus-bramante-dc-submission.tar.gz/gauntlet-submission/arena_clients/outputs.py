from __future__ import annotations

import base64
import re
from pathlib import Path
from typing import Any

_IMAGE_EXTENSIONS = {"image/png": "png", "image/jpeg": "jpg", "image/webp": "webp"}


def missing_tools_note(result: Any) -> str:





    try:
        score = result.get("score") if isinstance(result, dict) else getattr(result, "score", None)
        missing = score.get("missing_required_tools") if isinstance(score, dict) else None
        if isinstance(missing, (list, tuple)) and missing:
            return "Missing required tools: " + ", ".join(str(name) for name in missing)
        return ""
    except Exception:
        return ""


def submission_summary_lines(result: Any) -> list[str]:






    try:
        if isinstance(result, dict):
            accepted = result.get("accepted")
            status = result.get("status")
            score = result.get("score")
        else:
            accepted = getattr(result, "accepted", None)
            status = getattr(result, "status", None)
            score = getattr(result, "score", None)
        lines = [f"Accepted: {accepted}"]
        if status:
            lines.append(f"Status: {status}")
        if isinstance(score, dict) and score.get("final_score") is not None:
            lines.append(f"Score: {score['final_score']}")
        note = missing_tools_note(result)
        if note:
            lines.append(note)
        judge_error = score.get("judge_error") if isinstance(score, dict) else None
        if judge_error:

            lines.append(f"Judge error: {judge_error} (quality 0 until the image can be judged)")
        return lines
    except Exception as exc:
        return [f"Submission result unavailable ({type(exc).__name__})"]


def save_submitted_image(agent_id: str, image_uri: Any, root: Path) -> str:





    try:
        header, _, data = str(image_uri or "").partition(",")
        if not header.startswith("data:image/") or ";base64" not in header:
            return "not saved (not an inline image)"
        mime = header[len("data:"):].split(";")[0]
        extension = _IMAGE_EXTENSIONS.get(mime, "img")
        safe_id = re.sub(r"[^A-Za-z0-9_-]", "_", str(agent_id))[:64] or "agent"
        out_dir = Path(root) / "outputs"
        out_dir.mkdir(exist_ok=True)
        path = out_dir / f"{safe_id}-submission.{extension}"
        path.write_bytes(base64.b64decode(data, validate=True))
        return f"saved to {path}"
    except Exception as exc:
        return f"not saved ({type(exc).__name__})"
