from __future__ import annotations

from dataclasses import dataclass
import json
import os
import time
from typing import Any

import requests

from .config import get_api_base, get_arena_api_key


@dataclass
class SessionInfo:


    session_id: str
    agent_id: str
    agent_name: str
    status: str
    started_at: float


@dataclass
class SubmitResult:


    accepted: bool
    agent_id: str
    answer: str
    score: dict[str, Any] | None
    status: str


class HttpArenaClient:






    def __init__(
        self,
        api_base: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ) -> None:








        self.api_base = get_api_base(api_base)
        self.api_key = get_arena_api_key(api_key)
        self.timeout = timeout

    def _request(
        self,
        method: str,
        path: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:

        url = f"{self.api_base}{path}"

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-Arena-API-Key"] = self.api_key

        try:
            response = requests.request(
                method,
                url,
                headers=headers,
                json=data if data is not None else None,
                timeout=self.timeout,
            )
            if response.status_code >= 400:
                raise ArenaAPIError(response.status_code, response.text)
            return response.json()
        except requests.RequestException as e:
            raise ArenaConnectionError(str(e)) from e

    def health(self) -> dict[str, Any]:

        return self._request("GET", "/api/health")

    def register(
        self,
        agent_id: str,
        agent_name: str | None = None,
    ) -> SessionInfo:









        data = {"agent_id": agent_id}
        if agent_name:
            data["agent_name"] = agent_name

        raw_timeout_s = os.getenv("ARENA_REGISTRATION_TIMEOUT_S", "600")
        try:
            timeout_s = float(raw_timeout_s)
        except ValueError:
            timeout_s = 600.0
        if timeout_s <= 0:
            timeout_s = 600.0
        deadline = time.monotonic() + timeout_s
        delay_s = 1.0
        while True:
            try:
                result = self._request("POST", "/api/session/register", data)
                break
            except ArenaAPIError as e:
                if e.status_code == 409:
                    if e.code == "registration_too_late":
                        raise ArenaConnectionError(
                            "Registration is closed for the current round. "
                            "Register during the next lobby."
                        ) from e
                    remaining_s = deadline - time.monotonic()
                    if remaining_s <= 0:
                        timeout_label = f"{timeout_s:g}"
                        raise ArenaConnectionError(
                            "Registration did not open within "
                            f"{timeout_label} seconds."
                        ) from e
                    print("   Lobby is not open yet. Waiting for organizer...", flush=True)
                    time.sleep(min(delay_s, remaining_s))
                    delay_s = min(delay_s * 2.0, 10.0)
                else:
                    raise

        return SessionInfo(
            session_id=result["session_id"],
            agent_id=result["agent_id"],
            agent_name=result["agent_name"],
            status=result["status"],
            started_at=result["started_at"],
        )

    def update_status(
        self,
        agent_id: str,
        status: str,
        client_metrics: dict[str, Any] | None = None,
    ) -> bool:







        payload: dict[str, Any] = {"agent_id": agent_id, "status": status}
        if client_metrics:
            payload["client_metrics"] = client_metrics
        result = self._request(
            "POST",
            "/api/status",
            payload,
        )
        return result.get("updated", False)

    def broadcast_thought(self, agent_id: str, thought: str) -> bool:









        result = self._request(
            "POST",
            "/api/thought",
            {
                "agent_id": agent_id,
                "thought": thought,
            },
        )
        return result.get("accepted", False)

    def save_draft(
        self,
        agent_id: str,
        draft: str,
        rationale: str | None = None,
    ) -> bool:










        data = {"agent_id": agent_id, "draft": draft}
        if rationale:
            data["rationale"] = rationale

        result = self._request("POST", "/api/draft", data)
        return result.get("saved", False)

    def submit(
        self,
        agent_id: str,
        answer: str,
        client_metrics: dict[str, Any] | None = None,
        challenge_type: str | None = None,
    ) -> SubmitResult:














        payload: dict[str, Any] = {
            "agent_id": agent_id,
            "answer": answer,
            "client_metrics": client_metrics or {},
        }
        if challenge_type is not None:
            payload["challenge_type"] = challenge_type
        result = self._request(
            "POST",
            "/api/submit",
            payload,
        )

        return SubmitResult(
            accepted=result["accepted"],
            agent_id=result["agent_id"],
            answer=result["answer"],
            score=result.get("score"),
            status=result["status"],
        )

    def get_session(self, agent_id: str) -> dict[str, Any]:








        return self._request("GET", f"/api/session/{agent_id}")

    def get_leaderboard(self) -> list[dict[str, Any]]:





        return self._request("GET", "/api/leaderboard")

    def get_competition(self) -> dict[str, Any]:

        return self._request("GET", "/api/competition")

    def fetch_usage_scope(self) -> str | None:




        try:
            competition = self.get_competition()
        except Exception:
            return None
        scope = str(competition.get("usage_scope") or "").strip()
        return scope or None


class ArenaAPIError(Exception):


    def __init__(self, status_code: int, message: str):
        code: str | None = None
        try:
            payload = json.loads(message)
        except (TypeError, json.JSONDecodeError):
            payload = None
        if isinstance(payload, dict):
            detail = payload.get("detail")
            if isinstance(detail, dict):
                raw_code = detail.get("code")
                if isinstance(raw_code, str) and raw_code.strip():
                    code = raw_code.strip()

        self.status_code = status_code
        self.message = message
        self.code = code
        super().__init__(f"API error {status_code}: {message}")


class ArenaConnectionError(Exception):


    pass
