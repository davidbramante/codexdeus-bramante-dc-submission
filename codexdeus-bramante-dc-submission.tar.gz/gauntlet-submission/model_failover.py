import asyncio
from email.utils import parsedate_to_datetime
from datetime import timezone
import json
import math
import time


class ModelPoolExhausted(RuntimeError):
    terminal = True


class ModelAccessFailure(RuntimeError):
    terminal = True


class ModelPolicyRefusal(RuntimeError):
    terminal = True


class ModelRateLimited(RuntimeError):
    terminal = True


def retry_after_seconds(exc,*,wall_now=None):

    headers=getattr(getattr(exc,'response',None),'headers',{}) or {}
    value=headers.get('retry-after') or headers.get('Retry-After')
    if not isinstance(value,str) or not value or len(value)>80:return None
    try:
        result=float(value)
        return result if math.isfinite(result) and result>=0 else None
    except ValueError:pass
    try:
        stamp=parsedate_to_datetime(value)
        if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=timezone.utc)
        return max(0.0,stamp.timestamp()-(time.time() if wall_now is None else wall_now))
    except (ValueError,TypeError,OverflowError):return None


class UnusableModelResponse(ValueError):
    pass


class ModelFailover:
    def __init__(self,model_order,advertised_models,send,*,per_attempt_s=20.0,
                 max_switches=3,max_requests=12,max_attempts_per_call=4,clock=time.monotonic,on_event=None,
                 max_rate_retries=2,sleeper=asyncio.sleep):
        advertised=set(advertised_models)
        self.models=list(dict.fromkeys(m for m in model_order if isinstance(m,str) and m in advertised))
        if not self.models:raise ValueError('No advertised model available for failover')
        if not math.isfinite(per_attempt_s) or per_attempt_s<=0 or min(max_requests,max_attempts_per_call)<1 or max_switches<0:
            raise ValueError('Invalid model recovery limits')
        if type(max_rate_retries) is not int or not 0<=max_rate_retries<=3:
            raise ValueError('Invalid rate retry limit')
        self.max_rate_retries=max_rate_retries;self.sleeper=sleeper
        self.send=send;self.per_attempt_s=per_attempt_s;self.max_switches=max_switches
        self.max_requests=max_requests;self.max_attempts_per_call=max_attempts_per_call;self.clock=clock
        self.on_event=on_event;self.events=[];self.blocked=set();self.output_problems={}
        self.current=self.models[0];self.switches=0;self.requests=0;self.prompt_tokens=0;self.completion_tokens=0
        self.terminal_failure=None

    def event(self,kind,**values):
        item={'event':kind,'model':self.current,**values};self.events.append(item)
        if self.on_event:self.on_event(dict(item))

    def _select(self):
        if self.terminal_failure:raise self.terminal_failure('Model recovery is terminal')
        if self.current not in self.blocked:return self.current
        if self.switches>=self.max_switches:raise ModelPoolExhausted('Model switch budget exhausted')
        replacement=next((m for m in self.models if m not in self.blocked),None)
        if replacement is None:raise ModelPoolExhausted('All advertised candidates failed')
        previous=self.current;self.current=replacement;self.switches+=1
        self.event('model_switched',previous_model=previous,switch_number=self.switches)
        return replacement

    def feedback(self,reason,*,severe=False):
        self.output_problems[self.current]=self.output_problems.get(self.current,0)+1
        self.event('model_output_problem',reason=reason,count=self.output_problems[self.current])
        if severe or self.output_problems[self.current]>=2:
            self.blocked.add(self.current)
            self.event('model_circuit_opened',reason=reason)

    def useful(self):
        if self.current not in self.blocked:self.output_problems[self.current]=0

    def _usage(self,response):
        raw=response.get('usage') if isinstance(response,dict) else None
        raw=raw if isinstance(raw,dict) else {}
        counts={k:v for k in ('prompt_tokens','completion_tokens') if type(v:=raw.get(k)) is int and v>=0}
        self.prompt_tokens+=counts.get('prompt_tokens',0);self.completion_tokens+=counts.get('completion_tokens',0)
        return counts

    def _message(self,response):
        try:
            choice=response['choices'][0];message=choice['message']
            if not isinstance(choice,dict) or not isinstance(message,dict):raise ValueError()
            if response.get('usage') is not None and not isinstance(response['usage'],dict):raise ValueError()
            if message.get('refusal') or choice.get('finish_reason')=='content_filter':
                raise ModelPolicyRefusal('Provider refused this request')
            if choice.get('finish_reason')=='length':raise UnusableModelResponse('Truncated completion')
            content=message.get('content');calls=message.get('tool_calls')
            if content is not None and not isinstance(content,str):raise ValueError()
            if calls is not None and not isinstance(calls,list):raise ValueError()
            if not (isinstance(content,str) and content.strip()) and not calls:raise ValueError()
        except ModelPolicyRefusal:raise
        except (KeyError,IndexError,TypeError,ValueError) as exc:
            raise UnusableModelResponse('Empty, truncated, or malformed completion') from None
        return message

    async def complete(self,messages,tools,timeout):
        if not math.isfinite(timeout) or timeout<=0:raise TimeoutError('No model time remains')
        deadline=self.clock()+timeout

        transcript=json.dumps(messages);definitions=json.dumps(tools)
        last=None;rate_retries=0
        for _ in range(self.max_attempts_per_call):
            alias=self._select()
            if self.requests>=self.max_requests:raise ModelPoolExhausted('Model request budget exhausted')
            remaining=deadline-self.clock()
            if remaining<=.01:raise TimeoutError('Model recovery deadline exhausted')
            backup_available=self.switches<self.max_switches and any(m not in self.blocked and m!=alias for m in self.models)
            cap=min(self.per_attempt_s,remaining*.6 if backup_available else remaining)
            self.requests+=1;started=self.clock()
            self.event('model_attempt_started',request_number=self.requests,timeout_s=cap)
            try:
                response=await asyncio.wait_for(self.send(alias,json.loads(transcript),json.loads(definitions),cap),timeout=cap)
                counts=self._usage(response)
                self.event('model_attempt_returned',elapsed_s=self.clock()-started,usage=counts)
                self._message(response)
                return response
            except asyncio.CancelledError:
                self.event('model_attempt_canceled',elapsed_s=self.clock()-started)
                raise
            except ModelPolicyRefusal:
                self.terminal_failure=ModelPolicyRefusal
                self.event('model_policy_refusal')
                raise
            except Exception as exc:

                if getattr(exc,'status_code',None) in {401,403}:
                    self.terminal_failure=ModelAccessFailure
                    self.event('model_access_failure',status_code=exc.status_code)
                    raise ModelAccessFailure('Arena model access was rejected') from None
                if getattr(exc,'status_code',None)==429 or type(exc).__name__=='RateLimitError':
                    hint=retry_after_seconds(exc)
                    self.event('model_rate_limited',status_code=429,retry_after_s=hint,
                        elapsed_s=self.clock()-started)
                    wait=hint if hint is not None else 2.0*(2**rate_retries)
                    remaining=deadline-self.clock()
                    retry=(rate_retries<self.max_rate_retries and _+1<self.max_attempts_per_call
                        and self.requests<self.max_requests and wait+.1<remaining)
                    if not retry:
                        self.event('model_rate_limit_stopped',retry_budget_available=rate_retries<self.max_rate_retries)
                        raise ModelRateLimited('Rate cooldown exceeds the remaining bounded retry window') from None
                    rate_retries+=1
                    self.event('model_rate_limit_wait',wait_s=wait,retry_number=rate_retries)
                    try:await asyncio.wait_for(self.sleeper(wait),timeout=max(.01,remaining-.01))
                    except asyncio.CancelledError:
                        self.event('model_rate_limit_wait_canceled');raise
                    continue
                self.blocked.add(alias);last=exc
                self.event('model_attempt_failed',elapsed_s=self.clock()-started,error_type=type(exc).__name__)
        raise ModelPoolExhausted('Bounded model attempts exhausted') from None

    def snapshot(self):
        return {'current_model':self.current,'switches':self.switches,'requests':self.requests,
                'blocked_models':sorted(self.blocked),'prompt_tokens':self.prompt_tokens,
                'completion_tokens':self.completion_tokens,'events':list(self.events),
                'rate_limit_policy':{'max_retries_per_call':self.max_rate_retries,'unknown_retry_delays_s':[2,4,8],
                    'same_alias_retries':True,'honor_retry_after':True},
                'limits':{'max_switches':self.max_switches,'max_requests':self.max_requests,
                          'max_attempts_per_call':self.max_attempts_per_call,'per_attempt_s':self.per_attempt_s}}
