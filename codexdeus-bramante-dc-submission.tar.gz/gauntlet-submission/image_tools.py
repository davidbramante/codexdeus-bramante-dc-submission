import asyncio
import base64
import re
import time
from urllib.parse import urlsplit

try:
    from .model_failover import retry_after_seconds
except ImportError:
    from model_failover import retry_after_seconds

from jsonschema import Draft202012Validator
from referencing import Registry

MAX_BYTES=30*1024**2
TERMINAL_CODES={'unauthorized','forbidden','policy_refusal','content_filter','safety_block'}


def render_prompt(challenge,proposed,operation,*,profile='constraints'):







    if profile not in {'baseline','constraints'}:raise ValueError('Unknown image prompt profile')
    if not isinstance(proposed,str) or not proposed.strip() or len(proposed)>16000:raise ValueError('Invalid rendering prompt')
    if profile=='baseline':return proposed
    original=challenge.get('edit_prompt') or challenge.get('prompt') or challenge.get('description') or ''
    notes=challenge.get('reference_notes') or ''
    if not isinstance(original,str) or not isinstance(notes,str) or len(original)+len(notes)>16000:
        raise ValueError('Oversized or invalid image task')


    parts=[original]
    if notes and notes not in original:parts.append('Context: '+notes)


    if operation=='image_edit':
        parts.append('Apply exactly the requested change. Keep all other details unchanged, including facial features and subject identity.')
    else:
        parts.append('Treat every constraint in the request as a hard rule (count, colors, layout, style, exclusions). Single coherent scene, clean composition.')


    source=(original+'\n'+notes).lower()
    no_text=any(s in source for s in ('no text','without text','no words','no lettering','no logo','watermark'))
    keep_text=bool(re.search(r'\b(?:preserve|keep|retain|include|show)\b[^.;\n]{0,35}\b(?:existing|required|exact|specified)\b[^.;\n]{0,20}\b(?:text|words|label|lettering)\b',source,re.I))
    if no_text and not keep_text:
        parts.append('No text anywhere: no letters, words, numbers, captions, signage, logos or watermarks. Signs, screens and neon must show only abstract shapes and light, never characters.')

    parts.append('Standard resolution only (about 1024 px on the longest side); no HD, 4K or upscaling.')
    return '\n\n'.join(parts)


def failed(reply):
    return not isinstance(reply,dict) or bool(reply.get('error')) or bool(reply.get('isError')) or reply.get('ok') is False or reply.get('success') is False or str(reply.get('status','')).lower() in {'error','failed','failure'}


def image_data(uri):
    if not isinstance(uri,str) or len(uri)>MAX_BYTES*4//3+100:raise ValueError('Missing or oversized image URI')
    if uri.startswith('https://'):
        parsed=urlsplit(uri)
        if not parsed.hostname or parsed.username or parsed.password or any(c.isspace() for c in uri):raise ValueError('Invalid HTTPS image URI')
        return None,None
    formats={'data:image/png;base64,':('png',lambda b:b.startswith(b'\x89PNG\r\n\x1a\n')),
             'data:image/jpeg;base64,':('jpg',lambda b:b.startswith(b'\xff\xd8\xff')),
             'data:image/webp;base64,':('webp',lambda b:len(b)>=12 and b[:4]==b'RIFF' and b[8:12]==b'WEBP')}
    for prefix,(suffix,valid) in formats.items():
        if uri.startswith(prefix):
            data=base64.b64decode(uri[len(prefix):],validate=True)
            if not data or len(data)>MAX_BYTES or not valid(data):raise ValueError('Image encoding/header mismatch')
            return data,suffix
    raise ValueError('Unsupported image URI')


class ImageTools:
    def __init__(self,definitions,models,invoke,*,deadline,per_attempt_s=60,clock=time.monotonic):
        self.definitions={d['name']:d for d in definitions if isinstance(d,dict) and isinstance(d.get('name'),str)}
        self.models=list(dict.fromkeys(models));self.invoke=invoke;self.deadline=deadline
        self.per_attempt_s=per_attempt_s;self.clock=clock;self.blocked=set();self.switches=0
        self.outputs={};self.events=[];self.requests=0;self.terminal=None;self.attempted_models=set()

    def problem(self,payload):
        return '' if payload in self.outputs else 'Select an existing RESULT_IMAGE_N token returned by a successful image tool. Never return INPUT_IMAGE, a guessed token, or a URI.'

    def normalize(self,reply):
        if failed(reply):return reply if isinstance(reply,dict) else {'error':'Invalid image-tool response'}
        valid=[]
        for field in ('image_uri','image','url'):
            uri=reply.get(field)
            if not isinstance(uri,str):continue
            try:image_data(uri)
            except (ValueError,TypeError):continue
            valid.append((field,uri))
        if not valid:return {'error':'Image tool produced no supported image output','code':'missing_image_output'}
        result=dict(reply)
        for field,uri in valid:
            token=next((k for k,v in self.outputs.items() if v==uri),None)
            if token is None:token='RESULT_IMAGE_'+str(len(self.outputs)+1);self.outputs[token]=uri
            result[field]=token
        return result

    async def call(self,name,arguments):
        if self.terminal:return dict(self.terminal)
        definition=self.definitions.get(name,{})
        schema=definition.get('inputSchema',{})
        supports_model=isinstance(schema.get('properties'),dict) and 'model' in schema['properties']
        selected=arguments.get('model')
        if supports_model and not any(m not in self.blocked for m in self.models):
            return {'error':'No healthy advertised image model remains','code':'image_pool_exhausted'}
        if supports_model and selected is not None and selected not in self.models:
            return {'error':'Choose an advertised image-capable model','code':'unadvertised_image_model'}
        first=selected if selected not in self.blocked else None
        if first is None and supports_model:first=next((m for m in self.models if m not in self.blocked),None)
        candidates=[first]
        if supports_model:candidates += [m for m in self.models if m!=first and m not in self.blocked]
        last={'error':'No image time remains'}
        for index,alias in enumerate(candidates):
            if index and (self.switches>=1 or not supports_model):break
            if alias in self.blocked:continue
            if self.requests>=4:return {'error':'Image request budget exhausted'}
            remaining=self.deadline-self.clock()
            if remaining<=.05:break
            args=dict(arguments)
            if supports_model and alias:args['model']=alias
            try:Draft202012Validator(schema,registry=Registry()).validate(args)
            except Exception:
                if index:continue
                return {'error':'Image arguments do not match the discovered schema'}
            if alias not in self.attempted_models:
                if self.attempted_models and self.switches>=1:break
                if self.attempted_models:self.switches+=1
                self.attempted_models.add(alias)
            backup=index==0 and self.switches<1 and len(candidates)>1
            cap=min(self.per_attempt_s,remaining*.6 if backup else remaining)
            self.requests+=1;started=self.clock()
            limited=False;retry_after=None
            try:
                reply=await asyncio.wait_for(self.invoke(name,args),timeout=cap)
                if isinstance(reply,dict):
                    status=reply.get('status_code')
                    limited=(type(status) is int and status==429) or str(reply.get('code','')).lower() in {
                        'rate_limited','rate_limit_exceeded','too_many_requests'}
                last={'error':'Image service rate limited'} if limited else self.normalize(reply)
            except asyncio.CancelledError:raise
            except Exception as exc:
                last={'error':'Image tool request failed','error_type':type(exc).__name__}
                status=getattr(exc,'status_code',None)
                if status is None:status=getattr(getattr(exc,'response',None),'status_code',None)
                limited=(type(status) is int and status==429) or type(exc).__name__=='RateLimitError'
                if limited:retry_after=retry_after_seconds(exc)
                if status in (401,403):last['code']='unauthorized'
            if limited:
                self.events.append({'event':'image_rate_limited','tool':name,'model':alias,
                    'elapsed_s':self.clock()-started,'successful':False,'request':self.requests,
                    'timeout_s':cap,'status_code':429,'retry_after_s':retry_after})
                self.terminal={'error':'Image service rate limited; no further renderer calls in this run',
                    'code':'rate_limited','status_code':429}
                return dict(self.terminal)
            self.events.append({'tool':name,'model':alias,'elapsed_s':self.clock()-started,
                                'successful':not failed(last),'request':self.requests,'timeout_s':cap})
            if not failed(last):return last
            error_text=str(last.get('error','')).lower()
            if (str(last.get('code','')).lower() in TERMINAL_CODES or last.get('status_code') in (401,403) or
                any(term in error_text for term in ('content policy','content_filter','safety block','moderation','unauthorized','forbidden'))):
                self.terminal=last;return last
            self.blocked.add(alias)
        return last

    def snapshot(self):
        return {'requests':self.requests,'switches':self.switches,'events':self.events,
                'outputs':list(self.outputs),'semantic_quality_validated':False,
                'terminal_error':bool(self.terminal),
                'limits':{'max_requests':4,'max_switches':1,'per_attempt_s':self.per_attempt_s},
                'note':'Image-tool backend calls, separate from planner proxy request/token counts.'}


def preserve_input_artifact(directory,uri):

    import hashlib
    import json
    from pathlib import Path
    try:
        data,suffix=image_data(uri)
        directory=Path(directory);directory.mkdir(parents=True,exist_ok=True);directory.chmod(0o700)
        if data is None:
            if len(uri)>8192:raise ValueError('Input reference exceeds limit')
            path=directory/'input-image-reference.json'
            with path.open('x') as handle:
                path.chmod(0o600);json.dump({'uri':uri,'fetched':False},handle);handle.write('\n')
            return {'saved':True,'kind':'unfetched_https_reference','file':path.name,
                'uri_sha256':hashlib.sha256(uri.encode()).hexdigest(),'image_bytes_saved':False}
        path=directory/('input-image.'+suffix)
        with path.open('xb') as handle:path.chmod(0o600);handle.write(data)
        return {'saved':True,'kind':'inline_image','file':path.name,'bytes':len(data),
            'sha256':hashlib.sha256(data).hexdigest(),'image_bytes_saved':True,
            'semantic_quality_validated':False}
    except Exception as exc:
        return {'saved':False,'error_type':type(exc).__name__}
