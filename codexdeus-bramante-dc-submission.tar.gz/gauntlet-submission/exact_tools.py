from __future__ import annotations

import ast
from decimal import Decimal, DecimalException, localcontext
import re

DEFINITIONS=[
    {"name":"local_calculate","description":"Evaluate bounded decimal arithmetic exactly: +, -, *, /, %, parentheses. Returns a decimal string. Also supports min(a,b,...) and max(a,b,...) with 2-8 scalar arguments. No variables, other functions, powers, or network access.","inputSchema":{"type":"object","properties":{"expression":{"type":"string","minLength":1,"maxLength":500}},"required":["expression"],"additionalProperties":False}},
    {"name":"local_rank","description":"Sort numeric values in increasing order, breaking ties alphabetically by name. Use after calculating costs; accepts decimal strings.","inputSchema":{"type":"object","properties":{"items":{"type":"array","minItems":1,"maxItems":20,"items":{"type":"object","properties":{"name":{"type":"string","minLength":1,"maxLength":80},"value":{"type":"string","maxLength":100}},"required":["name","value"],"additionalProperties":False}}},"required":["items"],"additionalProperties":False}},
]


def bounded(value):
    if not value.is_finite() or abs(value)>Decimal('1e24') or value.as_tuple().exponent < -100:
        raise ValueError("Nonfinite or oversized numeric value")
    return value


def calculate(expression: str) -> str:
    if not isinstance(expression,str) or not 0<len(expression)<=500:
        raise ValueError("Expression must contain 1–500 characters")
    source=expression.strip()
    tree=ast.parse(source,mode="eval")
    if sum(1 for _ in ast.walk(tree))>128:
        raise ValueError("Expression is too complex")
    def visit(node,depth=0):
        if depth>16:raise ValueError("Expression is too deeply nested")
        if isinstance(node,ast.Constant) and type(node.value) in (int,float):
            token=ast.get_source_segment(source,node)
            if not token or not re.fullmatch(r"(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?",token):
                raise ValueError("Use decimal literals only")
            return bounded(Decimal(token))
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            value=visit(node.operand,depth+1)
            return value if isinstance(node.op,ast.UAdd) else -value
        if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult,ast.Div,ast.Mod)):
            left,right=visit(node.left,depth+1),visit(node.right,depth+1)
            if isinstance(node.op,ast.Add):value=left+right
            elif isinstance(node.op,ast.Sub):value=left-right
            elif isinstance(node.op,ast.Mult):value=left*right
            elif isinstance(node.op,ast.Div):value=left/right
            else:value=left%right
            return bounded(value)
        if (isinstance(node,ast.Call) and isinstance(node.func,ast.Name)
                and node.func.id in {'min','max'} and not node.keywords
                and 2<=len(node.args)<=8):
            values=[visit(item,depth+1) for item in node.args]
            return bounded(min(values) if node.func.id=='min' else max(values))
        raise ValueError("Only decimal arithmetic operators are supported")
    with localcontext() as ctx:
        ctx.prec=50
        value=visit(tree.body)
        if value==0:return '0'
        rendered=format(value,'f')
        return rendered.rstrip('0').rstrip('.') if '.' in rendered else rendered


def execute(name: str, arguments: dict) -> dict:
    try:
        if name=='local_calculate':return {"value":calculate(arguments['expression']),"numeric_precision":"50 significant decimal digits; repeating division rounded"}
        if name=='local_rank':
            items=arguments['items']
            if not 1<=len(items)<=20:raise ValueError("Invalid item count")
            names=[i['name'] for i in items]
            if len(set(names))!=len(names):raise ValueError("Names must be unique")
            ranked=sorted(items,key=lambda i:(bounded(Decimal(i['value'])),i['name']))
            return {"order":[i['name'] for i in ranked]}
        return {"error":"Unknown local capability"}
    except (ValueError,KeyError,TypeError,DecimalException,SyntaxError,RecursionError):
        return {"error":"Invalid or unsupported bounded arithmetic input"}
