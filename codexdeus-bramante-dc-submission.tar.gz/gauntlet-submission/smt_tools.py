from __future__ import annotations

import asyncio
import importlib.util
import json
import os
from pathlib import Path
import sys

RELATIONS = ('before','after','immediately_before','adjacent','not_adjacent')
DEFINITION = {
    'name':'local_smt_order',
    'description':('Solve a finite ordering puzzle with Z3. Translate EVERY clue into constraints; '
                   'positions are 1-based. Returns a checked order, uniqueness, or unsatisfiable/unknown. '
                   'A nonunique result means more clues may be needed. This verifies encoded constraints '
                   'only, not that your translation covers the task. No generated code is accepted.'),
    'inputSchema':{'type':'object','additionalProperties':False,'required':['items','constraints'],
      'properties':{
        'items':{'type':'array','minItems':1,'maxItems':12,'uniqueItems':True,
                 'items':{'type':'string','minLength':1,'maxLength':60}},
        'constraints':{'type':'array','maxItems':128,'items':{'oneOf':[
          {'type':'object','additionalProperties':False,'required':['relation','a','b'],
           'properties':{'relation':{'enum':list(RELATIONS)},'a':{'type':'string'},'b':{'type':'string'}}},
          {'type':'object','additionalProperties':False,'required':['relation','a','position'],
           'properties':{'relation':{'enum':['at','not_at']},'a':{'type':'string'},
                         'position':{'type':'integer','minimum':1,'maximum':12}}}
          ,{'type':'object','additionalProperties':False,'required':['relation','a','b','steps'],
            'properties':{'relation':{'enum':['distance']},'a':{'type':'string'},'b':{'type':'string'},
                          'steps':{'type':'integer','minimum':1,'maximum':11}}}
        ]}}
      }}
}


def validate_problem(problem):
    if not isinstance(problem,dict) or set(problem)!={'items','constraints'}:
        raise ValueError('Expected items and constraints only')
    names=problem['items'];clauses=problem['constraints']
    if not isinstance(names,list) or not 1<=len(names)<=12:
        raise ValueError('Expected 1–12 items')
    if any(not isinstance(n,str) or not 1<=len(n)<=60 for n in names) or len(set(names))!=len(names):
        raise ValueError('Names must be bounded and unique')
    if not isinstance(clauses,list) or len(clauses)>128:
        raise ValueError('Expected at most 128 constraints')
    for clause in clauses:
        if not isinstance(clause,dict):raise ValueError('Expected constraint objects')
        relation=clause.get('relation')
        if not isinstance(relation,str):raise ValueError('Invalid relation')
        keys={'relation','a','b'} if relation in RELATIONS else {'relation','a','b','steps'} if relation=='distance' else {'relation','a','position'}
        if set(clause)!=keys or clause.get('a') not in names:raise ValueError('Unknown item or fields')
        if relation in RELATIONS or relation=='distance':
            if clause.get('b') not in names:raise ValueError('Unknown item')
            if relation=='distance' and (type(clause['steps']) is not int or not 1<=clause['steps']<len(names)):
                raise ValueError('Invalid distance')
        elif relation in ('at','not_at'):
            position=clause['position']
            if type(position) is not int or not 1<=position<=len(names):raise ValueError('Invalid position')
        else:raise ValueError('Unsupported relation')
    return problem


def check_order(problem, order):

    validate_problem(problem)
    if len(order)!=len(problem['items']) or set(order)!=set(problem['items']):return False
    positions={name:i+1 for i,name in enumerate(order)}
    for c in problem['constraints']:
        a=positions[c['a']];r=c['relation']
        b=positions[c['b']] if 'b' in c else c['position']
        valid={'before':a<b,'after':a>b,'immediately_before':a+1==b,
               'adjacent':abs(a-b)==1,'not_adjacent':abs(a-b)!=1,
               'at':a==b,'not_at':a!=b,'distance':abs(a-b)==c.get('steps',0)}[r]
        if not valid:return False
    return True


def solve_problem(problem):
    validate_problem(problem)

    import z3
    import time
    names=problem['items']
    variables={name:z3.Int('position_'+str(i)) for i,name in enumerate(names)}
    solver=z3.Solver()
    solver.set(timeout=600,rlimit=250000)
    solver.add(z3.Distinct(list(variables.values())))
    for v in variables.values():solver.add(v>=1,v<=len(names))
    for index,c in enumerate(problem['constraints']):
        a=variables[c['a']];r=c['relation'];b=variables[c['b']] if 'b' in c else c['position']
        condition={'before':lambda:a<b,'after':lambda:a>b,'immediately_before':lambda:a+1==b,
                   'adjacent':lambda:z3.Abs(a-b)==1,'not_adjacent':lambda:z3.Abs(a-b)!=1,
                   'at':lambda:a==b,'not_at':lambda:a!=b,
                   'distance':lambda:z3.Abs(a-b)==c['steps']}[r]()
        solver.assert_and_track(condition,'clue_'+str(index))
    verdict=solver.check()
    if verdict!=z3.sat:
        result={'status':'unsatisfiable' if verdict==z3.unsat else 'unknown',
                'unique':None,'translation_verified':False}
        if verdict==z3.unsat:
            result['conflicting_constraint_indices']=sorted(int(str(label).split('_')[1]) for label in solver.unsat_core())
        return result
    model=solver.model()
    assignment={name:model.eval(v).as_long() for name,v in variables.items()}
    order=sorted(names,key=assignment.get)
    if not check_order(problem,order):raise RuntimeError('Independent constraint check failed')
    solver.push()
    solver.add(z3.Or([v!=assignment[name] for name,v in variables.items()]))
    second=solver.check()
    result={'status':'satisfiable','order':order,'unique':True if second==z3.unsat else False if second==z3.sat else None,
            'constraints_checked':len(problem['constraints']),'translation_verified':False}
    if second==z3.sat:
        alternate=solver.model()
        alternative=sorted(names,key=lambda name:alternate.eval(variables[name]).as_long())
        if not check_order(problem,alternative):raise RuntimeError('Alternative check failed')
        result['alternative_order']=alternative
    solver.pop()
    if second==z3.sat:

        canonical=[];remaining=set(names);end=time.monotonic()+.15
        for position in range(1,len(names)+1):
            selected=None
            for name in sorted(remaining):
                budget_ms=int((end-time.monotonic())*1000)
                if budget_ms<1:break
                solver.set(timeout=min(600,budget_ms))
                solver.push();solver.add(variables[name]==position)
                candidate=solver.check();solver.pop()
                if candidate==z3.unknown:break
                if candidate==z3.sat:selected=name;break
            if selected is None:break
            solver.add(variables[selected]==position);canonical.append(selected);remaining.remove(selected)
        result['canonical_witness']=len(canonical)==len(names)
        if result['canonical_witness']:
            if not check_order(problem,canonical):raise RuntimeError('Canonical witness check failed')
            result['order']=canonical
            result['alternative_order']=order if order!=canonical else alternative
            result['witness_policy']='lexicographically_smallest_valid_order'
        else:result['witness_policy']='valid_witness_canonicalization_budget_exhausted'
    return result


def available():
    return sys.platform=='linux' and importlib.util.find_spec('z3') is not None


async def execute(problem):
    try:validate_problem(problem)
    except (ValueError,TypeError):return {'error':'Invalid bounded ordering constraints'}
    if not available():return {'error':'Optional Z3 solver is not installed in this Linux runtime'}
    process=None
    try:

        process=await asyncio.create_subprocess_exec(sys.executable,'-I',str(Path(__file__).resolve()),'--worker',
            stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.DEVNULL,
            env={'LANG':'C.UTF-8'})
        output,_=await asyncio.wait_for(process.communicate(json.dumps(problem).encode()),2.5)
        if process.returncode or len(output)>16384:return {'error':'Bounded SMT worker failed'}
        return json.loads(output)
    except (asyncio.TimeoutError,ValueError,OSError):
        return {'error':'SMT worker exceeded its budget or was unavailable'}
    finally:
        if process is not None and process.returncode is None:
            process.kill();await process.wait()


if __name__=='__main__':
    if sys.argv[1:]!=['--worker'] or sys.platform!='linux':raise SystemExit(2)
    import resource
    resource.setrlimit(resource.RLIMIT_AS,(768*1024**2,768*1024**2))
    resource.setrlimit(resource.RLIMIT_CPU,(2,2))
    resource.setrlimit(resource.RLIMIT_FSIZE,(0,0))
    resource.setrlimit(resource.RLIMIT_NOFILE,(32,32))
    raw=sys.stdin.buffer.read(65537)
    if len(raw)>65536:raise SystemExit(2)
    try:print(json.dumps(solve_problem(json.loads(raw))))
    except Exception:raise SystemExit(1) from None
