import asyncio
import time


async def wait_for_challenge(mcp,agent_id,modality,*,timeout_s=600,poll_s=1,clock=time.monotonic):
    deadline=clock()+timeout_s
    tool='arena.image.get_challenge' if modality=='image' else 'arena.get_challenge'
    transient={'lobby','waiting','countdown','not_started','not_running','challenge_not_started','battle_not_started','round_not_started'}
    while clock()<deadline:
        data=await asyncio.wait_for(mcp.call_tool(tool,{'agent_id':agent_id}),timeout=min(20,max(.1,deadline-clock())))
        if not isinstance(data,dict):raise ValueError('Challenge response must be an object')
        phase=str(data.get('phase') or data.get('status') or '').lower()
        code=str(data.get('code') or '').lower()
        error=str(data.get('error') or '').lower()
        if phase in transient or code in transient or any(x in error for x in ['not started','not running','waiting for','countdown','lobby']):
            await asyncio.sleep(min(poll_s,max(0,deadline-clock())))
            continue
        if data.get('error'):raise RuntimeError('Arena rejected the challenge request')
        return data,clock()
    raise TimeoutError('No challenge opened before the lobby deadline')


def exception_diagnostic(exc):

    import re
    from pathlib import PurePath
    safe=lambda value: re.sub(r'[^A-Za-z0-9_.<>-]', '_', value)[:80]
    leaves=[];seen=set()
    def visit(error,depth=0):
        if id(error) in seen or len(leaves)>=8 or depth>5:return
        seen.add(id(error))
        children=getattr(error,'exceptions',None)
        if isinstance(children,tuple) and children:
            for child in children[:8]:visit(child,depth+1)
            return
        row={'type':safe(type(error).__name__)}
        status=getattr(error,'status_code',None)
        if status is None:status=getattr(getattr(error,'response',None),'status_code',None)
        if type(status) is int and 100<=status<=599:row['http_status']=status
        frames=[];tb=error.__traceback__
        while tb is not None:
            frames.append({'file':safe(PurePath(tb.tb_frame.f_code.co_filename).name),
                           'function':safe(tb.tb_frame.f_code.co_name),'line':tb.tb_lineno})
            tb=tb.tb_next
        if frames:row['locations']=frames[-4:]
        leaves.append(row)
    visit(exc)
    return {'type':safe(type(exc).__name__),'leaves':leaves}


def retryable_mcp_setup(exc):

    if isinstance(exc,asyncio.CancelledError):return False
    children=getattr(exc,'exceptions',None)
    if isinstance(children,tuple) and children:
        return all(retryable_mcp_setup(child) for child in children)

    status=getattr(exc,'status_code',None)
    if status is None:status=getattr(getattr(exc,'response',None),'status_code',None)
    if status is not None:return type(status) is int and status in {502,503,504}
    if type(exc).__name__ in {'SSLError','SSLCertVerificationError','CertificateError'}:return False
    cause=exc.__cause__;seen=set()
    while cause is not None and id(cause) not in seen:
        seen.add(id(cause))
        if type(cause).__name__ in {'SSLError','SSLCertVerificationError','CertificateError'}:return False
        cause=cause.__cause__
    return isinstance(exc,(TimeoutError,ConnectionError)) or type(exc).__name__ in {
        'ReadError','WriteError','ConnectError','ReadTimeout','ConnectTimeout','RemoteProtocolError',
        'EndOfStream','BrokenResourceError','ClosedResourceError'}


def owned_mcp(client,*,on_event=None,setup_timeout_s=15,transport_factory=None,session_factory=None):






    import math
    from contextlib import AsyncExitStack,asynccontextmanager
    if not math.isfinite(setup_timeout_s) or setup_timeout_s<=0:raise ValueError('Invalid MCP setup budget')
    if transport_factory is None:
        from mcp.client.sse import sse_client
        transport_factory=sse_client
    if session_factory is None:
        from mcp import ClientSession
        session_factory=ClientSession
    emit=on_event or (lambda event:None)

    @asynccontextmanager
    async def manage():
        deadline=time.monotonic()+setup_timeout_s
        for attempt in range(2):
            yielded=False
            try:
                async with AsyncExitStack() as stack:

                    async with asyncio.timeout(max(.001,deadline-time.monotonic())):
                        read,write=await stack.enter_async_context(transport_factory(client.sse_url,headers=client._headers))
                        session=await stack.enter_async_context(session_factory(read,write))
                        client._session=session
                        await session.initialize()
                    emit({'event':'mcp_connected','attempt':attempt+1})
                    yielded=True
                    yield client
                return
            except BaseException as exc:
                if yielded:raise
                retry=attempt==0 and retryable_mcp_setup(exc) and deadline-time.monotonic()>.1
                emit({'event':'mcp_setup_failed','attempt':attempt+1,'retry':retry,'error':exception_diagnostic(exc)})
                if not retry:raise
                await asyncio.sleep(min(.05,max(0,deadline-time.monotonic())))
            finally:
                client._session=None
    return manage()


def managed_mcp_type(base,*,owner=owned_mcp):

    class ManagedMcpClient(base):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.connection_events=[]
            self._owned_context=None

        async def __aenter__(self):
            self._owned_context=owner(self,on_event=self.connection_events.append)
            try:return await self._owned_context.__aenter__()
            except BaseException:
                self._owned_context=None
                raise

        async def __aexit__(self,*args):
            if self._owned_context is None:raise RuntimeError('MCP context was not entered')
            try:return await self._owned_context.__aexit__(*args)
            finally:self._owned_context=None
    return ManagedMcpClient


def wait_for_running(http, agent_id, *, allow_missing_phase=False, timeout_s=600):

    from arena_clients.http_client import ArenaAPIError, ArenaConnectionError

    deadline = time.monotonic() + timeout_s
    transitions = []
    while time.monotonic() < deadline:
        competition = {}
        phase = None
        for read in (http.get_competition, http.health):
            try:
                state = read()
            except ArenaAPIError as exc:
                if exc.status_code == 404:
                    continue
                if exc.status_code in (502, 503, 504):
                    break
                raise
            except ArenaConnectionError:
                break
            if read == http.get_competition and isinstance(state, dict):
                competition = state
            if isinstance(state, dict) and state.get('phase'):
                phase = str(state['phase']).strip().lower()
                break
        else:
            if allow_missing_phase:
                return {'phases': transitions, 'roster_member': None}
        if phase and (not transitions or phase != transitions[-1]):
            transitions.append(phase)
        if phase == 'running':
            roster = competition.get('eligible_agent_ids')
            member = agent_id in roster if isinstance(roster, list) else None
            if competition.get('enforce_gate') is True and member is False:
                raise RuntimeError('Agent absent from the frozen roster')
            return {'phases': transitions, 'roster_member': member}
        time.sleep(min(0.5, max(0, deadline - time.monotonic())))
    raise TimeoutError('Organizer GO was not observed before the phase deadline')
