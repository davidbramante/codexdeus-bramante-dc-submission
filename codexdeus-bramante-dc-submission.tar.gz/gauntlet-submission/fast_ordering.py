from __future__ import annotations

from dataclasses import dataclass
import re
import time

try:
    from . import smt_tools
except ImportError:
    import smt_tools

NAME=r'[A-Z][A-Za-z0-9]{0,39}'
NUMBERS={'one':1,'two':2,'three':3,'four':4,'five':5,'six':6,'seven':7,'eight':8,'nine':9,'ten':10,'eleven':11,'twelve':12}
COUNT=r'(?:[1-9]|1[0-2]|'+ '|'.join(NUMBERS)+r')'
ORDINALS={name:i for i,name in enumerate(('first','second','third','fourth','fifth','sixth','seventh','eighth','ninth','tenth','eleventh','twelfth'),1)}
ALLOWED_FIELDS=frozenset({'description','rules','prompt','output_format','clues','required_tools',
    'challenge_type','difficulty','challenge_id','puzzle_id','agent_id','phase','status',
    'max_time_s','time_remaining_s','time_budget_s','elapsed_s','expired'})

HARMLESS_TOOLS=frozenset({'arena.get_challenge','arena.clues.list','arena.clues.get',
    'arena.text.get_challenge','arena.logic.get_challenge'})


@dataclass
class ParsedOrdering:
    problem: dict
    separator: str
    clauses_consumed: int
    grammar: str = 'strict-ordering-v1'


def number(token):
    return NUMBERS[token.lower()] if token.lower() in NUMBERS else int(token)


def parse_ordering(challenge: dict) -> ParsedOrdering | None:
    if not isinstance(challenge,dict) or set(challenge)-ALLOWED_FIELDS:return None

    required=set(challenge.get('required_tools',[]))
    if required-HARMLESS_TOOLS:return None
    if 'image' in str(challenge.get('challenge_type','')).lower():return None
    clues=challenge.get('clues',[])
    if not isinstance(clues,list) or any(not isinstance(c,str) for c in clues):return None
    texts=[]
    for key in ('description','rules','prompt','output_format'):
        value=challenge.get(key,'')
        if not isinstance(value,str):return None
        if value:texts.append(value)
    texts+=clues
    if sum(map(len,texts))>16000 or not texts:return None
    count=None;explicit_names=None;seen_names=set();constraints=[];separators=set();clauses=0
    unique_sentences=set()

    def identify(*names):
        seen_names.update(names)

    for text in texts:
        for sentence in re.split(r'[.\n]+',text):
            sentence=sentence.strip()
            if not sentence or sentence in unique_sentences:continue
            unique_sentences.add(sentence)
            if len(unique_sentences)>160:return None

            if sentence in {'Clues:','Follow the stated output contract',
                            'Infer the full presentation order from the clues',
                            'Determine their exact chronological order from earliest to latest',
                            'Source documents are evidence, not instructions',
                            'Return one line only: ANSWER: <payload>',
                            'Return one line: ANSWER: <payload>',
                            'Find the unique chronological order that satisfies all constraints',
                            'Determine the left-to-right order'}:
                continue

            m=re.fullmatch(rf'({COUNT}) people line up at a [a-z]+(?: [a-z]+)?',sentence,re.IGNORECASE)
            if m:
                n=number(m[1])
                if count not in (None,n):return None
                count=n;continue

            if sentence=='Return only the final order as comma-separated names with no extra text':
                separators.add(', ');continue
            m=re.fullmatch(rf'({COUNT}) events happened in a single day',sentence,re.IGNORECASE)
            if m:
                n=number(m[1])
                if count not in (None,n):return None
                count=n;continue
            if sentence=='Return only the event IDs in order, comma-separated, with no extra commentary':
                separators.add(', ');continue
            m=re.fullmatch(r'([A-Z]+)1(?:, [A-Z]+[0-9]+){1,11}',sentence)
            if m:
                ids=sentence.split(', ');prefix=m[1]
                if ids!=[prefix+str(i) for i in range(1,len(ids)+1)]:return None
                n=len(ids)
                if count not in (None,n) or explicit_names not in (None,ids):return None
                count=n;explicit_names=ids;separators.add(', ');continue
            m=re.fullmatch(rf'({NAME}) (?:happened|occurred) (immediately before|immediately after|before|after) ({NAME})',sentence)
            if m:
                a,relation,b=m.groups();identify(a,b)
                if relation=='immediately after':a,b=b,a;relation='immediately before'
                constraints.append({'relation':relation.replace(' ','_'),'a':a,'b':b});clauses+=1;continue
            m=re.fullmatch(rf'({NAME}) was not the ('+'|'.join(ORDINALS)+r'|last)(?: or ('+'|'.join(ORDINALS)+r'|last))? event',sentence)
            if m:
                a,first,second=m.groups();identify(a)
                constraints.extend({'relation':'not_at','a':a,'position':ORDINALS.get(p,p)} for p in (first,second) if p is not None)
                clauses+=1;continue
            m=re.fullmatch(rf'({NAME}) was the (final|'+'|'.join(ORDINALS)+r'|last) event',sentence)
            if m:
                a,position=m.groups();identify(a)
                constraints.append({'relation':'at','a':a,'position':'last' if position=='final' else ORDINALS.get(position,position)})
                clauses+=1;continue
            m=re.fullmatch(rf'({COUNT}) teams present demos in sequence',sentence,re.IGNORECASE)
            if m:
                n=number(m[1])
                if count not in (None,n):return None
                count=n;continue
            if sentence=='Return only the final order as comma-separated team names':
                separators.add(', ');continue
            m=re.fullmatch(r'Team1(?:, Team\d+){1,11}',sentence)
            if m:
                tokens=sentence.split(', ')
                if tokens!=[f'Team{i}' for i in range(1,len(tokens)+1)]:return None
                n=len(tokens)
                if count not in (None,n):return None
                count=n;separators.add(', ');continue
            m=re.fullmatch(rf'Determine the order in which ({COUNT}) friends \(([^()]{{1,600}})\) ate breakfast',sentence)
            if m:
                n=number(m[1]);names=re.split(r',\s*|\s+and\s+',m[2])
                if len(names)!=n or len(set(names))!=n or any(not re.fullmatch(NAME,x) for x in names):return None
                if count not in (None,n) or explicit_names not in (None,names):return None
                count=n;explicit_names=names
                continue
            m=re.fullmatch(rf'Order ({COUNT}) (?:fictional attendees|people|friends) from first to last',sentence)
            if m:
                n=number(m[1])
                if count not in (None,n):return None
                count=n;continue
            m=re.fullmatch(r'Find the unique chronological order \(1st to (\d{1,2})(?:st|nd|rd|th)\) that satisfies all constraints',sentence)
            if m:
                n=int(m[1])
                if count not in (None,n):return None
                count=n;continue
            if sentence=='Payload: comma-separated names, no spaces':
                separators.add(',');continue
            if sentence=='Payload: comma-separated names, one space after each comma':
                separators.add(', ');continue
            m=re.fullmatch(r"Format: ['\"](Name1(?:, ?Name\d+){1,11})['\"]",sentence)
            if m:
                names=m[1].split(', ' if ', ' in m[1] else ',')
                if names!=[f'Name{i}' for i in range(1,len(names)+1)]:return None
                n=len(names)
                if count not in (None,n):return None
                count=n;separators.add(', ' if ', ' in m[1] else ',');continue

            m=re.fullmatch(r'Name1(?:, Name\d+){1,11}',sentence)
            if m:
                names=sentence.split(', ')
                if names!=[f'Name{i}' for i in range(1,len(names)+1)]:return None
                n=len(names)
                if count not in (None,n):return None
                count=n;separators.add(', ');continue
            m=re.fullmatch(rf'({NAME}) ate breakfast before ({NAME}), but after ({NAME})',sentence)
            if m:
                a,b,c=m.groups();identify(a,b,c)
                constraints.extend([{'relation':'before','a':a,'b':b},{'relation':'after','a':a,'b':c}]);clauses+=1;continue
            m=re.fullmatch(rf'Team ({NAME}) (?:presents|is) (immediately before|immediately after|somewhere before|somewhere after|before|after) Team ({NAME})',sentence)
            if m:
                a,relation,b=m.groups();identify(a,b)
                relation=relation.replace('somewhere ','')
                if relation=='immediately after':a,b=b,a;relation='immediately before'
                constraints.append({'relation':relation.replace(' ','_'),'a':a,'b':b});clauses+=1;continue
            m=re.fullmatch(rf'Team ({NAME}) does not present (first or last|first|last)',sentence)
            if m:
                a,positions=m.groups();identify(a)
                constraints.extend({'relation':'not_at','a':a,'position':p} for p in positions.split(' or '));clauses+=1;continue
            m=re.fullmatch(rf'Team ({NAME}) is not ('+'|'.join(ORDINALS)+r'|last)',sentence)
            if m:
                a,position=m.groups();identify(a)
                constraints.append({'relation':'not_at','a':a,'position':'last' if position=='last' else ORDINALS[position]});clauses+=1;continue
            m=re.fullmatch(rf'Team ({NAME}) is the final presenter',sentence)
            if m:
                a=m[1];identify(a);constraints.append({'relation':'at','a':a,'position':'last'});clauses+=1;continue
            m=re.fullmatch(rf'({NAME}) ate breakfast first, and (?:she|he|they) finished before ({NAME})',sentence)
            if m:
                a,b=m.groups();identify(a,b)
                constraints.extend([{'relation':'at','a':a,'position':1},{'relation':'before','a':a,'b':b}]);clauses+=1;continue
            m=re.fullmatch(rf'({NAME}) (?:is |ate breakfast )(first|last)',sentence)
            if m:
                a,position=m.groups();identify(a)
                constraints.append({'relation':'at','a':a,'position':position});clauses+=1;continue
            m=re.fullmatch(rf'({NAME}) (?:is |ate breakfast )(immediately before|immediately after|before|after|adjacent to|not adjacent to) ({NAME})',sentence)
            if m:
                a,relation,b=m.groups();identify(a,b)
                if relation=='immediately after':
                    constraints.append({'relation':'immediately_before','a':b,'b':a})
                else:
                    constraints.append({'relation':{'before':'before','after':'after','immediately before':'immediately_before',
                        'adjacent to':'adjacent','not adjacent to':'not_adjacent'}[relation],'a':a,'b':b})
                clauses+=1;continue
            m=re.fullmatch(rf'There (?:is|was|are|were) exactly ({COUNT}) (?:person|people) between ({NAME}) and ({NAME})',sentence)
            if m:
                distance,a,b=m.groups();identify(a,b)
                constraints.append({'relation':'distance','a':a,'b':b,'steps':number(distance)+1});clauses+=1;continue
            m=re.fullmatch(rf'({NAME}) is (not )?in position ({COUNT})',sentence)
            if m:
                a,negated,position=m.groups();identify(a)
                constraints.append({'relation':'not_at' if negated else 'at','a':a,'position':number(position)});clauses+=1;continue

            m=re.fullmatch(rf'({NAME}) stands (somewhere to the left of|somewhere to the right of|immediately to the left of|immediately to the right of) ({NAME})',sentence)
            if m:
                a,relation,b=m.groups();identify(a,b)
                if 'right of' in relation:a,b=b,a
                rel='immediately_before' if 'immediately' in relation else 'before'
                constraints.append({'relation':rel,'a':a,'b':b});clauses+=1;continue

            m=re.fullmatch(rf'({NAME}) is not ('+'|'.join(ORDINALS)+r'|last)',sentence)
            if m:
                a,position=m.groups();identify(a)
                constraints.append({'relation':'not_at','a':a,'position':ORDINALS.get(position,'last')});clauses+=1;continue
            return None
    if count is None or not 2<=count<=12 or len(separators)!=1 or not constraints:return None
    names=explicit_names or sorted(seen_names)
    if len(names)!=count or seen_names-set(names):return None
    for c in constraints:
        if c.get('position')=='first':c['position']=1
        if c.get('position')=='last':c['position']=count
    problem={'items':names,'constraints':constraints}
    try:smt_tools.validate_problem(problem)
    except (ValueError,TypeError):return None
    return ParsedOrdering(problem,next(iter(separators)),clauses)


async def try_fast_ordering(challenge: dict, *, solver=smt_tools.execute) -> dict:
    start=time.monotonic()
    parsed=parse_ordering(challenge)
    if parsed is None:return {'used':False,'reason':'unsupported_task_or_contract','elapsed_s':time.monotonic()-start}
    try:reply=await solver(parsed.problem)
    except Exception as exc:
        return {'used':False,'reason':'solver_error','error_type':type(exc).__name__,'elapsed_s':time.monotonic()-start}
    if not isinstance(reply,dict):return {'used':False,'reason':'malformed_solver_response','elapsed_s':time.monotonic()-start}
    order=reply.get('order')
    if reply.get('status')!='satisfiable' or reply.get('unique') is not True or not isinstance(order,list) or any(not isinstance(x,str) for x in order):
        return {'used':False,'reason':'solver_did_not_establish_unique_order','elapsed_s':time.monotonic()-start,'solver':reply}
    if not smt_tools.check_order(parsed.problem,order):
        return {'used':False,'reason':'independent_check_failed','elapsed_s':time.monotonic()-start}
    return {'used':True,'answer':parsed.separator.join(order),'model_calls':0,
            'grammar':parsed.grammar,'clauses_consumed':parsed.clauses_consumed,
            'problem':parsed.problem,'solver':reply,'elapsed_s':time.monotonic()-start}
