import asyncio
import hashlib
import json
import math
import os
from pathlib import Path
import time
import tempfile

try:
    from .arena_clients.http_client import ArenaConnectionError
except ImportError:
    from arena_clients.http_client import ArenaConnectionError


async def submit_text_exact(http,payload,*,deadline,clock=time.monotonic,on_event=None,
                            receipt_timeout_s=30,max_attempts=2):
    if type(max_attempts) is not int or not 1<=max_attempts<=2:raise ValueError('Invalid submission attempt cap')
    if not math.isfinite(receipt_timeout_s) or not 0<receipt_timeout_s<=60:raise ValueError('Invalid receipt timeout')
    frozen=json.dumps(payload,sort_keys=True,allow_nan=False)
    for attempt in range(1,max_attempts+1):
        left=deadline-clock()
        if left<=.05:raise TimeoutError('No submission time remains')


        cap=receipt_timeout_s
        http.timeout=cap
        if on_event:on_event({'attempt':attempt,'event':'submission_attempt','timeout_s':cap})
        try:

            receipt=await asyncio.to_thread(http._request,'POST','/api/submit',json.loads(frozen))
            if on_event:on_event({'attempt':attempt,'event':'submission_receipt'})
            return receipt
        except (ArenaConnectionError,asyncio.TimeoutError) as exc:
            if on_event:on_event({'attempt':attempt,'event':'submission_transport_failure','error_type':type(exc).__name__})
            if attempt==max_attempts:raise
    raise RuntimeError('Unreachable submission state')


class UnsettledSubmission(RuntimeError):
    pass


def compact_receipt_summary(value,*,depth=0):

    if depth>16:return {'omitted_summary_depth':True,'raw_receipt':'submission-receipt.json'}
    if isinstance(value,str) and value.startswith('data:image/'):
        return {'payload':'image','sha256':hashlib.sha256(value.encode()).hexdigest(),
                'characters':len(value),'raw_receipt':'submission-receipt.json'}
    if isinstance(value,dict):return {k:compact_receipt_summary(v,depth=depth+1) for k,v in value.items()}
    if isinstance(value,list):return [compact_receipt_summary(v,depth=depth+1) for v in value]
    return value


class SubmissionGate:





    def __init__(self,path,agent_id,origin):
        self.path=Path(path);self.agent_id=agent_id;self.origin=origin

    def _read(self):
        if not self.path.exists():return None
        st=self.path.lstat()
        if self.path.is_symlink() or st.st_uid!=os.getuid() or st.st_mode&0o077 or st.st_size>32768:
            raise UnsettledSubmission('Pending submission checkpoint is not private and valid')
        data=json.loads(self.path.read_text())
        if data.get('agent_id')!=self.agent_id or data.get('origin')!=self.origin:
            raise UnsettledSubmission('Pending submission belongs to another configuration')
        return data

    def begin(self,*,started_at,puzzle_id,modality,answer,record_directory):
        if self._read() is not None:raise UnsettledSubmission('A previous submission is still unresolved')
        data={'agent_id':self.agent_id,'origin':self.origin,'started_at':started_at,'puzzle_id':puzzle_id,
              'modality':modality,'answer_sha256':hashlib.sha256(answer.encode()).hexdigest(),
              'record_directory':str(Path(record_directory).resolve()),'dispatched_at_unix':time.time()}
        self.path.parent.mkdir(parents=True,exist_ok=True);self.path.parent.chmod(0o700)
        with self.path.open('x') as handle:
            self.path.chmod(0o600);json.dump(data,handle,allow_nan=False);handle.flush();os.fsync(handle.fileno())
        folder=Path(data['record_directory']);folder.mkdir(parents=True,exist_ok=True);folder.chmod(0o700)
        p=folder/'submission-dispatch.json'
        with p.open('x') as handle:
            p.chmod(0o600);json.dump(data,handle,allow_nan=False);handle.flush();os.fsync(handle.fileno())
        return data

    @staticmethod
    def canonical_receipt(checkpoint,state):
        if not isinstance(state,dict) or state.get('agent_id')!=checkpoint['agent_id']:return None
        started=state.get('started_at')
        if type(started) not in (int,float) or started!=checkpoint['started_at']:return None
        metrics=state.get('metrics') or {}
        if not isinstance(metrics,dict):return None
        puzzle=state.get('puzzle_id') or metrics.get('puzzle_id')
        if puzzle!=checkpoint['puzzle_id'] or state.get('status')!='submitted':return None
        kind=state.get('challenge_type')
        if kind in {'text','image'} and kind!=checkpoint['modality']:return None
        answer=state.get('final_answer',state.get('answer'))
        if not isinstance(answer,str) or hashlib.sha256(answer.encode()).hexdigest()!=checkpoint['answer_sha256']:return None
        score=state.get('score')
        if not isinstance(score,dict) or score.get('judge_error') or score.get('pending_evaluation'):return None
        points=score.get('final_score')
        if type(points) not in (int,float) or not math.isfinite(points):return None
        return {'agent_id':state['agent_id'],'answer':answer,'status':state['status'],
                'accepted':metrics.get('submission_accepted',state.get('accepted')),'score':score,
                'recovered_from':'read_only_own_session','session_snapshot':state}

    def settled(self,receipt):
        checkpoint=self._read()
        if checkpoint is None:return
        if not isinstance(receipt,dict) or receipt.get('error'):raise UnsettledSubmission('Submission has no final receipt')
        raw=Path(checkpoint['record_directory'])/'submission-receipt.json'
        temporary=raw.with_suffix('.tmp')
        with temporary.open('w') as handle:
            temporary.chmod(0o600);json.dump(receipt,handle,allow_nan=False,default=str)
            handle.flush();os.fsync(handle.fileno())
        temporary.replace(raw)
        score=receipt.get('score') if isinstance(receipt,dict) else None
        if isinstance(score,dict) and (score.get('judge_error') or score.get('pending_evaluation')):
            raise UnsettledSubmission('Judging is still pending; checkpoint retained')
        p=Path(checkpoint['record_directory'])/'submission-resolution.json'
        tmp=p.with_suffix('.tmp')
        summary={k:v for k,v in receipt.items() if k not in {'answer','session_snapshot','score'}}
        if isinstance(score,dict):summary['score']={k:v for k,v in score.items() if k!='output_image_uri'}
        summary=compact_receipt_summary(summary)
        with tmp.open('w') as handle:
            tmp.chmod(0o600);json.dump({'checkpoint':checkpoint,'receipt_summary':summary,
                'full_receipt_sha256':hashlib.sha256(json.dumps(receipt,sort_keys=True,default=str).encode()).hexdigest(),
                'full_receipt_location':raw.name},handle,allow_nan=False,default=str)
        tmp.replace(p)

        if self._read()!=checkpoint:raise UnsettledSubmission('Submission checkpoint changed concurrently')
        self.path.unlink()

    async def reconcile(self,http,*,wait_s=30,poll_s=.5,clock=time.monotonic):
        checkpoint=self._read()
        if checkpoint is None:return None
        end=clock()+wait_s
        while True:
            try:
                http.timeout=min(3,max(.05,end-clock()))
                state=await asyncio.to_thread(http.get_session,self.agent_id)
                receipt=self.canonical_receipt(checkpoint,state)
                if receipt is not None:
                    self.settled(receipt)
                    return receipt
            except (ArenaConnectionError,asyncio.TimeoutError):pass
            if clock()>=end:raise UnsettledSubmission('Prior submission has no matching settled receipt; no registration allowed')
            await asyncio.sleep(min(poll_s,max(0,end-clock())))


def checkpoint_path(output, agent_id, *, local_coordinator, origin):
    name = agent_id + '-pending-submit.json'
    if local_coordinator:
        return output / name
    legacy = Path(__file__).with_name('outputs') / name
    if legacy.exists() or legacy.is_symlink():
        return legacy
    parent = Path(tempfile.gettempdir()) / ('gauntlet-state-' + str(os.getuid()))
    parent.mkdir(mode=0o700, exist_ok=True)
    st = parent.lstat()
    if parent.is_symlink() or not parent.is_dir() or st.st_uid != os.getuid() or st.st_mode & 0o077:
        raise UnsettledSubmission('Submission state directory is not private')
    scope = hashlib.sha256(origin.encode()).hexdigest()[:16]
    return parent / (scope + '-' + name)
