import asyncio
import json
import math

import httpx


async def fetch_model_rows(proxy,key,*,timeout_s,transport=None):
    if not math.isfinite(timeout_s) or timeout_s<=0:raise ValueError('Invalid metadata deadline')
    async with asyncio.timeout(timeout_s):
        async with httpx.AsyncClient(trust_env=False,transport=transport) as client:
            for attempt in range(2):
                try:
                    async with client.stream('GET',proxy.rstrip('/')+'/models',headers={'Authorization':'Bearer '+key},timeout=timeout_s) as response:
                        response.raise_for_status();data=bytearray()
                        async for chunk in response.aiter_bytes():
                            data.extend(chunk)
                            if len(data)>1024**2:raise ValueError('Model metadata exceeds limit')
                    payload=json.loads(data)
                    break
                except httpx.HTTPStatusError as exc:
                    if exc.response.status_code<500 or attempt:raise
                except httpx.TransportError:
                    if attempt:raise
                await asyncio.sleep(.05)
    raw=payload if isinstance(payload,list) else payload.get('data',payload.get('models',[])) if isinstance(payload,dict) else []
    if not isinstance(raw,list) or len(raw)>500:raise ValueError('Invalid model roster')
    rows=[];seen=set()
    for item in raw:
        row={'id':item} if isinstance(item,str) else item
        if not isinstance(row,dict):continue
        name=row.get('id')
        if not isinstance(name,str) or not name.strip() or len(name)>200 or name.strip() in seen:continue
        seen.add(name.strip());entry={'id':name.strip()}
        if 'capabilities' in row:entry['capabilities']=row['capabilities']
        rows.append(entry)
    if not rows:raise ValueError('No advertised models')
    return rows


async def load_clues(mcp,agent_id,data,*,timeout_s):
    inline=data.get('clues',[])
    if not isinstance(inline,list):data['unparsed_inline_clues']=inline;inline=[]
    obtained=[];incomplete=False;listed=False
    async def read(index,cid):
        nonlocal incomplete
        try:
            clue=await mcp.get_clue(cid,agent_id)
            if not isinstance(clue.text,str):raise ValueError('Invalid clue text')
            obtained.append((index,clue.text))
        except asyncio.CancelledError:raise
        except Exception:incomplete=True
    try:
        async with asyncio.timeout(timeout_s):
            ids=await mcp.list_clues(agent_id)
            if not isinstance(ids,list) or len(ids)>64:raise ValueError('Unsupported clue count')
            listed=True
            await asyncio.gather(*(read(i,cid) for i,cid in enumerate(ids)))
    except Exception:incomplete=True
    data['clues']=inline+[text for _,text in sorted(obtained) if text not in inline]
    if incomplete:data['clue_fetch_incomplete']=True
    return {'incomplete':incomplete,'fetched':len(obtained),'listed':listed,'timeout_s':timeout_s}


def completed_text_tools(clue_loading):

    tools=['arena.get_challenge']
    if clue_loading.get('listed'):tools.append('arena.clues.list')
    if clue_loading.get('fetched',0)>0:tools.append('arena.clues.get')
    return tools


def bind_tool_identity(name,arguments,definitions,agent_id):

    args=dict(arguments)
    definition=next((d for d in definitions if d.get('name')==name),{})
    properties=definition.get('inputSchema',{}).get('properties',{})
    if isinstance(properties,dict) and 'agent_id' in properties:args['agent_id']=agent_id
    return args


def normalize_mcp_reply(reply):

    if isinstance(reply,dict) and isinstance(reply.get('raw'),str) and reply['raw'].startswith('Error executing tool '):
        result={**reply,'error':reply['raw']}
        if 'not owned by this battle key' in reply['raw']:result['code']='forbidden'
        return result
    return reply


def rank_planners(available,*,modality="text"):

    if modality=='image':return list(dict.fromkeys(available))
    preferred=('gpt-5.6-terra','gpt-5.4','gemini-3.6-flash','nemotron-3-super')
    offered=list(dict.fromkeys(available))
    return [name for name in preferred if name in offered]+[name for name in offered if name not in preferred]
